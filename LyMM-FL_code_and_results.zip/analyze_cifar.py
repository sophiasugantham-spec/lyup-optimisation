import pickle, numpy as np, json
from scipy.stats import ttest_rel
M=["LyMM-FL","HD-MMFL","Oort","Random"]
R={m:[pickle.load(open(f"results/cifar/{m}_s{s}.pkl","rb")) for s in range(3)] for m in M}
f=dict(acc_mean=lambda r:r["last_acc"].mean()*100, cifar=lambda r:r["last_acc"][3]*100, digits=lambda r:r["last_acc"][0]*100,
 syn=lambda r:r["last_acc"][1]*100, bc=lambda r:r["last_acc"][2]*100, E=lambda r:r["E_mean"]*1e3, over=lambda r:r["frac_over"]*100,
 worst=lambda r:r["avgE_over_ebar"].max(), fail=lambda r:r["fail_rate"]*100, below=lambda r:r["frac_below"]*100, jain=lambda r:r["jain"],
 cifar_part=lambda r:r["part"][:,3][r["eligible"][:,3]].mean(), rt=lambda r:r["runtime"]*1e3, budget=lambda r:r["E_budget"]*1e3,
 elig=lambda r:r["eligible"].sum(), pairs=lambda r:r["n_pairs"])
out={}
for k,g in f.items():
    print(k.ljust(10)," | ".join(f"{m}: {np.mean([g(r) for r in R[m]]):.2f}±{np.std([g(r) for r in R[m]],ddof=1):.2f}" for m in M))
    out[k]={m:[float(g(r)) for r in R[m]] for m in M}
json.dump(out,open("results/cifar_summary.json","w"),indent=1)
