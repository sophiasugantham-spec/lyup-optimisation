import pickle, numpy as np
from scipy.stats import wilcoxon
V=["full","noQ","noZ","noDVFS","eqBW","myopic"]
R={v:[pickle.load(open(f"results/ablation/{v}_s{s}.pkl","rb")) for s in range(5)] for v in V}
f=dict(acc=lambda r:r["last_acc"].mean()*100, dig=lambda r:r["last_acc"][0]*100, syn=lambda r:r["last_acc"][1]*100,
 E=lambda r:r["E_mean"]*1e3, over=lambda r:r["frac_over"]*100, worst=lambda r:r["avgE_over_ebar"].max(),
 below=lambda r:r["frac_below"]*100, minp=lambda r:r["minpart"], jain=lambda r:r["jain"], ok=lambda r:r["ok"], fail=lambda r:r["fail_rate"]*100)
for k,g in f.items():
    print(k.ljust(6)," | ".join(f"{v}: {np.mean([g(r) for r in R[v]]):.3f}±{np.std([g(r) for r in R[v]],ddof=1):.3f}" for v in V))
