# LyMM-FL: code and experiments

Lyapunov-guided participant selection and resource scheduling for multi-model federated learning.

Requirements: Python 3.11+, numpy, scipy (>=1.9, HiGHS), scikit-learn, matplotlib.

| File | Purpose |
| --- | --- |
| env.py | Tasks (Digits MLP, Synthetic(1,1) softmax, BreastCancer logistic), device/channel/energy model, default parameters |
| solver.py | Per-round solver: Lemma 1 frequency, convex bandwidth allocation, dual decomposition, certificate |
| policies.py | LyMM-FL (with ablation switches) and baselines: HD-MMFL, Oort, FedCS, Greedy, MM-Assign, Random |
| sim.py | One federated run (FedAvg per model, failures, batteries) |
| metrics.py | Per-run metrics |
| exp.py | Experiment suites: `python3 exp.py main|ablation|scale|tradeoff|robust|cifar [workers]` |
| cnn.py | NumPy CNN for CIFAR-10 (place cifar-10-batches-py under /home/claude/data or edit load_cifar root) |
| gap.py | Optimality gap vs exhaustive search: `python3 gap.py 300 6` |
| analyze_*.py, figs_main.py, fig_scale.py, fig_trade.py | Tables and figures |

Results of every run are saved under results/<suite>/ as pickles; results/main_summary.json holds Table 5.
All methods share identical random channel/availability/harvest sequences per seed.
