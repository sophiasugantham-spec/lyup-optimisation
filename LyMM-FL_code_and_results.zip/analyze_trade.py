import pickle, numpy as np, os
rows=[]
def L(tag): return [pickle.load(open(f"results/tradeoff/{tag}_s{s}.pkl","rb")) for s in range(3)]
def main_full(): return [pickle.load(open(f"results/main/LyMM-FL_s{s}.pkl","rb")) for s in range(3)]
cfgs=[("V",V,f"V{V}") for V in [0.1,0.3,1,3,10]]+[("r",r,f"r{r}") for r in [0.0,0.05,0.15,0.2]]
res={}
for kind,val,tag in cfgs:
    R=L(tag)
    res[(kind,val)]=R
res[("r",0.1)]=main_full()
for (kind,val),R in sorted(res.items()):
    g=lambda f: (np.mean([f(r) for r in R]), np.std([f(r) for r in R],ddof=1))
    a=g(lambda r:r["last_acc"].mean()*100); e=g(lambda r:r["E_mean"]*1e3); w=g(lambda r:r["avgE_over_ebar"].max())
    ov=g(lambda r:r["frac_over"]*100); mp=g(lambda r:r["minpart"]); 
    tgt = val if kind=="r" else 0.1
    bl=g(lambda r:(r["part"][r["eligible"]]<tgt-1e-9).mean()*100); j=g(lambda r:r["jain"]); syn=g(lambda r:r["last_acc"][1]*100)
    print(f"{kind}={val:<5} acc={a[0]:.2f}±{a[1]:.2f} syn={syn[0]:.1f} E={e[0]:.1f} worst={w[0]:.3f} over={ov[0]:.1f} minp={mp[0]:.3f} below={bl[0]:.1f} jain={j[0]:.3f}")
pickle.dump({k:[{kk:r[kk] for kk in ("last_acc","E_mean","avgE_over_ebar","frac_over","minpart","part","eligible","jain")} for r in v] for k,v in res.items()},open("results/trade_summary.pkl","wb"))
