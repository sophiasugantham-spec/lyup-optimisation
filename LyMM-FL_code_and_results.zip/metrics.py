import numpy as np
def summarize(L, burn=0):
    E=L["energy"]; T=E.shape[0]
    avgE=E.mean(0)
    viol=np.maximum(avgE-L["hbar"],0)
    el=L["eligible"]
    part=L["ok"].mean(0)
    pe=part[el]
    J=(pe.sum()**2)/(len(pe)*(pe**2).sum()+1e-12)
    sel=L["x"].any(2).sum(1); ok=L["ok"].any(2).sum(1)
    fails=(L["fail_deadline"].sum()+L["fail_battery"].sum())/max(L["x"].any(2).sum(),1)
    acc=L["acc"]
    return dict(final_acc=acc[-1] if len(acc) else None, last_acc=acc[-4:].mean(0) if len(acc) else None,
                mean_acc_curve=acc.mean(1) if len(acc) else None,
                E_mean=E.mean(), E_budget=L["hbar"].mean(), viol_max=viol.max(), viol_mean=viol.mean(),
                frac_over=(avgE>L["hbar"]*1.0+1e-9).mean(),
                jain=J, minpart=pe.min() if len(pe) else np.nan, frac_below=(pe<0.1-1e-9).mean(),
                sel=sel.mean(), ok=ok.mean(), fail_rate=fails, depleted=L["depleted"].mean(),
                runtime=L["runtime"].mean(), gap=np.nanmean(L["gap"]), n_elig=el.sum(), n_pairs=L["a"].sum(),
                wasted=E.sum()-0)
