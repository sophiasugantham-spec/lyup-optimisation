"""Edge environment and federated learning tasks for LyMM-FL experiments.

Three genuinely different learning tasks share one pool of edge devices:
  task 0: handwritten digits (8x8 images, 10 classes), 2-layer MLP
  task 1: LEAF-style Synthetic(1,1) (60 features, 10 classes), softmax regression
  task 2: breast-cancer diagnosis (30 features, 2 classes), logistic regression
All system costs (cycles, payload) are derived from each model's real parameter count.
"""
import numpy as np
from sklearn.datasets import load_digits, load_breast_cancer
from sklearn.preprocessing import StandardScaler

BITS_PER_PARAM = 32


# ----------------------------------------------------------------------------- models
class SoftmaxModel:
    """Multinomial logistic regression (also used for binary with 2 classes)."""

    def __init__(self, d, c, rng):
        self.d, self.c = d, c
        self.shapes = [(d, c), (c,)]
        self.n_params = d * c + c

    def init(self, rng):
        return [rng.normal(0, 0.01, (self.d, self.c)), np.zeros(self.c)]

    def forward(self, w, X):
        z = X @ w[0] + w[1]
        z -= z.max(1, keepdims=True)
        p = np.exp(z)
        return p / p.sum(1, keepdims=True)

    def grad(self, w, X, y):
        p = self.forward(w, X)
        n = len(y)
        p[np.arange(n), y] -= 1
        p /= n
        return [X.T @ p, p.sum(0)]


class MLPModel:
    def __init__(self, d, h, c, rng):
        self.d, self.h, self.c = d, h, c
        self.n_params = d * h + h + h * c + c

    def init(self, rng):
        return [rng.normal(0, np.sqrt(2 / self.d), (self.d, self.h)), np.zeros(self.h),
                rng.normal(0, np.sqrt(2 / self.h), (self.h, self.c)), np.zeros(self.c)]

    def _fw(self, w, X):
        a = X @ w[0] + w[1]
        hdn = np.maximum(a, 0)
        z = hdn @ w[2] + w[3]
        z -= z.max(1, keepdims=True)
        p = np.exp(z)
        return a, hdn, p / p.sum(1, keepdims=True)

    def forward(self, w, X):
        return self._fw(w, X)[2]

    def grad(self, w, X, y):
        a, hdn, p = self._fw(w, X)
        n = len(y)
        p[np.arange(n), y] -= 1
        p /= n
        g2 = hdn.T @ p
        g3 = p.sum(0)
        dh = (p @ w[2].T) * (a > 0)
        return [X.T @ dh, dh.sum(0), g2, g3]


def loss_acc(model, w, X, y):
    p = model.forward(w, X)
    l = -np.log(p[np.arange(len(y)), y] + 1e-12)
    return l, (p.argmax(1) == y).mean()


# ----------------------------------------------------------------------------- data
def dirichlet_split(y, holders, alpha, rng, min_per=8):
    """Split indices of labels y over the list of holder devices with Dirichlet(alpha) label skew."""
    n_h = len(holders)
    classes = np.unique(y)
    for _ in range(50):
        parts = [[] for _ in range(n_h)]
        for c in classes:
            idx = rng.permutation(np.where(y == c)[0])
            prop = rng.dirichlet(alpha * np.ones(n_h))
            cuts = (np.cumsum(prop) * len(idx)).astype(int)[:-1]
            for j, chunk in enumerate(np.split(idx, cuts)):
                parts[j].extend(chunk.tolist())
        if min(len(p) for p in parts) >= min_per:
            break
    return {holders[j]: np.array(parts[j], dtype=int) for j in range(n_h)}


def synthetic_leaf(n_dev, rng, alpha=1.0, beta=1.0, d=60, c=10):
    """LEAF Synthetic(alpha, beta) generator (Caldas et al.; Li et al. FedProx)."""
    sizes = np.clip(rng.lognormal(4, 1, n_dev).astype(int) + 20, 20, 400)
    cov = np.diag(np.arange(1, d + 1) ** -1.2)
    Xs, ys = [], []
    for j in range(n_dev):
        u = rng.normal(0, alpha)
        B = rng.normal(0, beta)
        W = rng.normal(u, 1, (d, c))
        b = rng.normal(u, 1, c)
        v = rng.normal(B, 1, d)
        X = rng.multivariate_normal(v, cov, sizes[j])
        y = np.argmax(X @ W + b, 1)
        Xs.append(X)
        ys.append(y)
    return Xs, ys


class Task:
    def __init__(self, name, model, Xtr_dev, ytr_dev, Xte, yte, lr, batch):
        self.name, self.model = name, model
        self.Xtr, self.ytr = Xtr_dev, ytr_dev  # dict device -> arrays
        self.Xte, self.yte = Xte, yte
        self.lr, self.batch = lr, batch
        self.payload_bits = model.n_params * BITS_PER_PARAM


def build_tasks(N, rng, hold_prob=0.6, alpha_dir=0.5, cifar=False, cifar_train=6000, cifar_test=2000):
    """Return tasks and holder matrix a[i,k]."""
    K = 4 if cifar else 3
    a = (rng.random((N, K)) < hold_prob).astype(int)
    for i in range(N):
        if a[i].sum() == 0:
            a[i, rng.integers(K)] = 1
    for k in range(K):  # every task needs >= 3 holders
        if a[:, k].sum() < 3:
            a[rng.choice(N, 3, replace=False), k] = 1
    tasks = []
    # task 0: digits MLP
    dg = load_digits()
    X = dg.data / 16.0
    y = dg.target
    perm = rng.permutation(len(y))
    te, tr = perm[:360], perm[360:]
    holders = list(np.where(a[:, 0])[0])
    sp = dirichlet_split(y[tr], holders, alpha_dir, rng)
    tasks.append(Task("Digits-MLP", MLPModel(64, 64, 10, rng),
                      {i: X[tr][ix] for i, ix in sp.items()}, {i: y[tr][ix] for i, ix in sp.items()},
                      X[te], y[te], lr=0.1, batch=16))
    # task 1: synthetic(1,1) softmax
    holders = list(np.where(a[:, 1])[0])
    Xs, ys = synthetic_leaf(len(holders), rng)
    Xtr, ytr, Xte, yte = {}, {}, [], []
    for j, i in enumerate(holders):
        n = len(ys[j])
        cut = int(0.8 * n)
        Xtr[i], ytr[i] = Xs[j][:cut], ys[j][:cut]
        Xte.append(Xs[j][cut:])
        yte.append(ys[j][cut:])
    tasks.append(Task("Synthetic-LR", SoftmaxModel(60, 10, rng), Xtr, ytr,
                      np.vstack(Xte), np.concatenate(yte), lr=0.05, batch=16))
    # task 2: breast cancer logistic
    bc = load_breast_cancer()
    X = StandardScaler().fit_transform(bc.data)
    y = bc.target
    perm = rng.permutation(len(y))
    te, tr = perm[:114], perm[114:]
    holders = list(np.where(a[:, 2])[0])
    sp = dirichlet_split(y[tr], holders, alpha_dir, rng, min_per=3)
    tasks.append(Task("BreastCancer-LR", SoftmaxModel(30, 2, rng),
                      {i: X[tr][ix] for i, ix in sp.items()}, {i: y[tr][ix] for i, ix in sp.items()},
                      X[te], y[te], lr=0.05, batch=8))
    if cifar:
        from cnn import CNNModel, load_cifar
        global _CIFAR
        if "_CIFAR" not in globals():
            _CIFAR = load_cifar()
        Xtr_all, ytr_all, Xte_all, yte_all = _CIFAR
        tr = rng.choice(len(ytr_all), cifar_train, replace=False)
        te = rng.choice(len(yte_all), cifar_test, replace=False)
        holders = list(np.where(a[:, 3])[0])
        sp = dirichlet_split(ytr_all[tr], holders, alpha_dir, rng, min_per=20)
        tasks.append(Task("CIFAR10-CNN", CNNModel(),
                          {i: Xtr_all[tr][ix] for i, ix in sp.items()}, {i: ytr_all[tr][ix] for i, ix in sp.items()},
                          Xte_all[te], yte_all[te], lr=0.05, batch=32))
    return tasks, a


# ----------------------------------------------------------------------------- system
class EdgeSystem:
    """Device and channel parameters. Units: Hz, cycles, J, W, bits, s."""

    def __init__(self, N, tasks, a, rng, cfg):
        self.N, self.K, self.cfg = N, len(tasks), cfg
        self.a = a
        self.n = np.zeros((N, self.K))
        for k, t in enumerate(tasks):
            for i, y in t.ytr.items():
                self.n[i, k] = len(y)
        self.a = (self.n > 0).astype(int)
        E = cfg["local_epochs"]
        # cycles per sample = 6 FLOPs/param (fwd+bwd) x cycles per FLOP
        self.phi = np.array([getattr(t.model, "train_flops_per_sample", 6 * t.model.n_params) * cfg["cycles_per_flop"]
                             for t in tasks])
        self.cycles = E * self.phi[None, :] * self.n  # C_ik
        self.s = np.array([t.payload_bits for t in tasks], float)  # s_k
        self.fmax = rng.uniform(*cfg["fmax"], N)
        self.kappa = cfg["kappa"] * np.ones(N)
        self.p = rng.uniform(*cfg["ptx"], N)
        self.snr_db = rng.uniform(*cfg["snr_db"], N)  # mean SNR over full band
        self.W = cfg["bandwidth"]
        self.avail_p = rng.uniform(*cfg["avail"], N)
        self.hbar = rng.uniform(*cfg["harvest"], N)  # mean harvested J / round
        self.ebar = cfg["allowance"] * self.hbar  # long-term FL energy allowance (J / round)
        self.bmax = cfg["bmax"]
        self.battery = np.full(N, cfg["b0"])
        self.Delta = cfg["deadline"]
        # static eligibility: a pair is eligible if, alone on the full band at the mean channel,
        # it can meet the deadline at fmax within the maximum battery
        R0 = self.W * np.log2(1 + 10 ** (self.snr_db / 10))
        t_solo = self.cycles / self.fmax[:, None] + self.s[None, :] / R0[:, None]
        e_solo = self.kappa[:, None] * self.cycles * self.fmax[:, None] ** 2 + self.p[:, None] * self.s[None, :] / R0[:, None]
        self.eligible = (self.a > 0) & (t_solo <= self.Delta) & (e_solo <= self.bmax)

    def draw_round(self, rng):
        avail = rng.random(self.N) < self.avail_p
        h2 = rng.exponential(1.0, self.N)  # Rayleigh power gain
        snr = 10 ** (self.snr_db / 10) * h2
        R = self.W * np.log2(1 + snr)  # full-band rate (bit/s)
        harvest = rng.exponential(self.hbar)
        return avail, R, harvest

    # energy/time of device i for workload (C,S) with bandwidth share beta and CPU freq f
    def cost(self, i, C, S, beta, f, R):
        t_cmp = C / f if C > 0 else 0.0
        t_up = S / (beta * R[i]) if S > 0 else 0.0
        e = self.kappa[i] * C * f ** 2 + self.p[i] * t_up
        return t_cmp + t_up, e


GATEWAY_CFG = None  # set below

DEFAULT_CFG = dict(
    local_epochs=2,
    cycles_per_flop=20,       # MCU-class core, software-assisted float
    fmax=(5e7, 2e8),          # 50-200 MHz
    kappa=5e-26,              # J/(cycle Hz^2): ~0.5-2 nJ/cycle at 100-200 MHz
    ptx=(0.1, 0.25),          # W
    snr_db=(0, 20),
    bandwidth=1e6,            # 1 MHz shared uplink
    avail=(0.6, 1.0),
    harvest=(0.02, 0.10),     # J per round (mean)
    allowance=0.5,            # share of harvested energy FL may use on average
    bmax=1.0, b0=0.5,
    deadline=2.0,             # s per round
    dir_alpha=0.5,            # Dirichlet label-skew for digits and breast cancer
)

# Gateway-class devices for the four-task scenario with the CIFAR-10 CNN
GATEWAY_CFG = dict(DEFAULT_CFG,
    cycles_per_flop=1,        # SIMD-capable application core
    fmax=(3e8, 1.2e9),        # 0.3-1.2 GHz
    kappa=1e-28,              # J/(cycle Hz^2)
    ptx=(0.2, 0.5),
    bandwidth=5e6,
    harvest=(0.1, 0.5),
    bmax=5.0, b0=2.5,
    deadline=5.0,
    cifar=True,
)
