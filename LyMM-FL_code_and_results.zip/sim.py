"""One federated run: environment + policy + FedAvg on three tasks."""
import time
import numpy as np
from env import build_tasks, EdgeSystem, loss_acc, DEFAULT_CFG, GATEWAY_CFG
from policies import ALL_POLICIES, LyMMFL

POLICY_CFG = dict(V=1.0, gamma=0.02, cz=3.0, rmin=0.1, random_q=0.3, assign_q=0.5, oort_M=8, oort_eps=0.2,
                  hd_weights=(0.05, 0.05, 1.0), hd_qmax=0.5)


def local_train(task, w, X, y, epochs, rng):
    w = [p.copy() for p in w]
    n = len(y)
    for _ in range(epochs):
        perm = rng.permutation(n)
        for s in range(0, n, task.batch):
            b = perm[s:s + task.batch]
            g = task.model.grad(w, X[b], y[b])
            for p, gp in zip(w, g):
                p -= task.lr * gp
    return w


def make_policy(name, sysm, cfg, rng, **kw):
    if name.startswith("LyMM-FL"):
        return LyMMFL(sysm, cfg, rng, **kw)
    return ALL_POLICIES[name](sysm, cfg, rng)


def run(policy_name, seed, N=50, T=150, sys_cfg=None, pol_cfg=None, eval_every=5, train=True,
        policy_kw=None, record_gap=False):
    base = GATEWAY_CFG if (sys_cfg or {}).get("scenario") == "gateway" else DEFAULT_CFG
    sys_cfg = dict(base, **{k: v for k, v in (sys_cfg or {}).items() if k != "scenario"})
    pol_cfg = dict(POLICY_CFG, **(pol_cfg or {}))
    rng_env = np.random.default_rng(seed)
    tasks, a = build_tasks(N, rng_env, alpha_dir=sys_cfg.get("dir_alpha", 0.5), cifar=sys_cfg.get("cifar", False))
    sysm = EdgeSystem(N, tasks, a, rng_env, sys_cfg)
    rng_round = np.random.default_rng(seed + 1000)  # identical channel/availability across policies
    rng_pol = np.random.default_rng(seed + 2000)
    rng_train = np.random.default_rng(seed + 3000)
    pol = make_policy(policy_name, sysm, pol_cfg, rng_pol, **(policy_kw or {}))
    K = sysm.K
    w = [t.model.init(np.random.default_rng(seed + 7 + k)) for k, t in enumerate(tasks)]
    util = np.where(sysm.a > 0, 1.0, 0.0)  # unexplored pairs start at max utility
    raw_util = np.zeros((N, K))
    battery = sysm.battery.copy()
    log = dict(energy=np.zeros((T, N)), x=np.zeros((T, N, K)), ok=np.zeros((T, N, K)),
               fail_deadline=np.zeros(T), fail_battery=np.zeros(T), runtime=np.zeros(T),
               gap=np.full(T, np.nan), acc=[], acc_rounds=[], battery_min=np.zeros(T),
               depleted=np.zeros(T), hbar=sysm.ebar.copy(), a=sysm.a.copy(), n=sysm.n.copy(), eligible=sysm.eligible.copy())
    for t in range(T):
        avail, R, harvest = sysm.draw_round(rng_round)
        t0 = time.perf_counter()
        plan = pol.plan(t, avail, R, util, battery)
        log["runtime"][t] = time.perf_counter() - t0
        if record_gap and pol.last_gap is not None:
            log["gap"][t] = pol.last_gap
        energy = np.zeros(N)
        succ = {}
        for i, (m, beta, f) in plan.items():
            m = m & (sysm.a[i] > 0)
            if not m.any():
                continue
            C = sysm.cycles[i][m].sum()
            S = sysm.s[m].sum()
            ti, ei = sysm.cost(i, C, S, beta, f, R)
            log["x"][t, i] = m
            if ei > battery[i] + 1e-12:
                energy[i] = battery[i]
                log["fail_battery"][t] += 1
                continue
            energy[i] = ei
            if ti > sysm.Delta * (1 + 1e-6):
                log["fail_deadline"][t] += 1
                continue
            succ[i] = m
            log["ok"][t, i] = m
        battery = np.minimum(sysm.bmax, battery - energy + harvest)
        log["depleted"][t] = (battery < 1e-3).sum()
        log["battery_min"][t] = battery.min()
        log["energy"][t] = energy
        pol.observe(t, plan, succ, energy, util)
        # federated training
        if train:
            for k, task in enumerate(tasks):
                ups, wts = [], []
                for i, m in succ.items():
                    if not m[k]:
                        continue
                    X, y = task.Xtr[i], task.ytr[i]
                    l, _ = loss_acc(task.model, w[k], X, y)
                    raw_util[i, k] = len(y) * np.sqrt(np.mean(l ** 2))
                    ups.append(local_train(task, w[k], X, y, sys_cfg["local_epochs"], rng_train))
                    wts.append(len(y))
                if ups:
                    wts = np.array(wts, float) / sum(wts)
                    w[k] = [sum(wt * u[j] for wt, u in zip(wts, ups)) for j in range(len(w[k]))]
                seen = raw_util[:, k] > 0
                if seen.any():
                    mx = raw_util[seen, k].max()
                    util[seen, k] = raw_util[seen, k] / mx
            if t % eval_every == eval_every - 1 or t == T - 1:
                log["acc"].append([loss_acc(tk.model, w[k], tk.Xte, tk.yte)[1] for k, tk in enumerate(tasks)])
                log["acc_rounds"].append(t + 1)
    log["acc"] = np.array(log["acc"])
    log["Delta"] = sysm.Delta
    return log
