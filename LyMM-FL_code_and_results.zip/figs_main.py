import pickle, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

M = ["LyMM-FL", "HD-MMFL", "Oort", "FedCS", "Greedy", "MM-Assign", "Random"]
COL = dict(zip(M, ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6"]))
INK, MUTED, GRID = "#1f1f1e", "#6b6a64", "#e4e3de"
plt.rcParams.update({"font.size": 9, "axes.edgecolor": MUTED, "axes.labelcolor": INK, "xtick.color": MUTED,
                     "ytick.color": MUTED, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6, "font.family": "DejaVu Sans",
                     "legend.frameon": False, "savefig.dpi": 220, "savefig.bbox": "tight"})
R = {m: [pickle.load(open(f"results/main/{m}_s{s}.pkl", "rb")) for s in range(10)] for m in M}

# ---------------- Fig 2: learning curves
tasks = ["Digits (MLP)", "Synthetic(1,1) (softmax)", "BreastCancer (logistic)"]
fig, axs = plt.subplots(1, 3, figsize=(10, 3.0))
for k, ax in enumerate(axs):
    for m in M:
        A = np.array([r["acc_curve"][:, k] for r in R[m]]) * 100
        x = R[m][0]["acc_rounds"]
        mu, sd = A.mean(0), A.std(0)
        lw = 2.2 if m == "LyMM-FL" else 1.3
        ax.plot(x, mu, color=COL[m], lw=lw, label=m, zorder=3 if m == "LyMM-FL" else 2)
        if m in ("LyMM-FL", "HD-MMFL"):
            ax.fill_between(x, mu - sd, mu + sd, color=COL[m], alpha=0.12, lw=0)
    ax.set_title(tasks[k], fontsize=9, color=INK)
    ax.set_xlabel("Round")
axs[0].set_ylabel("Test accuracy (%)")
axs[0].set_ylim(40, 100); axs[1].set_ylim(20, 92); axs[2].set_ylim(80, 100)
h, l = axs[0].get_legend_handles_labels()
fig.tight_layout(rect=(0, 0.08, 1, 1))
fig.legend(h, l, loc="lower center", ncol=7, bbox_to_anchor=(0.5, -0.01))
fig.savefig("fig2_curves.png")

# ---------------- Fig 3: energy compliance and reliability
fig, axs = plt.subplots(1, 3, figsize=(10, 2.9))
def bar(ax, f, title, ylabel, ref=None, fmt="{:.2f}"):
    v = np.array([[f(r) for r in R[m]] for m in M])
    mu, sd = v.mean(1), v.std(1, ddof=1)
    y = np.arange(len(M))
    ax.barh(y, mu, xerr=sd, color=[COL[m] for m in M], height=0.62, error_kw=dict(ecolor=MUTED, lw=0.8))
    ax.set_yticks(y, M); ax.invert_yaxis(); ax.grid(axis="y", visible=False)
    ax.set_title(title, fontsize=9, color=INK); ax.set_xlabel(ylabel)
    if ref is not None:
        ax.axvline(ref, color=INK, lw=1, ls="--")
    for yi, m_ in zip(y, mu):
        ax.text(m_ + (sd.max() if sd.max() > 0 else 0) + 0.02 * ax.get_xlim()[1], yi, fmt.format(m_), va="center", fontsize=7.5, color=INK)
bar(axs[0], lambda r: r["avgE_over_ebar"].max(), "(a) Worst device: avg energy / allowance", "ratio (1 = on budget)", ref=1.0)
bar(axs[1], lambda r: r["frac_over"] * 100, "(b) Devices over their allowance", "% of devices", fmt="{:.0f}")
bar(axs[2], lambda r: r["fail_rate"] * 100, "(c) Failed participations", "% of selected device-rounds", fmt="{:.0f}")
for ax in axs[1:]:
    ax.set_yticklabels([])
fig.tight_layout()
fig.savefig("fig3_energy.png")

# ---------------- Fig 4: participation-rate distribution (pooled over seeds)
fig, ax = plt.subplots(figsize=(5.2, 3.0))
for m in M:
    p = np.sort(np.concatenate([r["part"][r["eligible"]] for r in R[m]]))
    ax.step(p, np.arange(1, len(p) + 1) / len(p), where="post", color=COL[m], lw=2.2 if m == "LyMM-FL" else 1.3, label=m)
ax.axvline(0.1, color=INK, lw=1, ls="--"); ax.text(0.105, 0.9, "r_min = 0.1", fontsize=7.5, color=INK)
ax.set_xlim(0, 0.6); ax.set_xlabel("Participation rate of a (device, model) pair"); ax.set_ylabel("Share of pairs (CDF)")
ax.legend(fontsize=7.5, loc="lower right")
fig.savefig("fig4_fairness.png")

# ---------------- Fig 1: per-round flow
fig, ax = plt.subplots(figsize=(10, 2.6)); ax.axis("off"); ax.set_xlim(0, 10); ax.set_ylim(0, 2.6)
boxes = [(0.1, "Observe state\navailability, channel,\nbattery, utility"),
         (2.05, "Prices from queues\nθ = V·u + Z\nω = (Vγ + Q)/ē"),
         (4.0, "Dual decomposition\nprice μ on bandwidth;\nper-device subset + β\n(Lemmas 1–2)"),
         (5.95, "Primal recovery\nconvex re-allocation,\ngreedy improvement,\ncertificate δ(t)"),
         (7.9, "Train & aggregate\nf* = C/(Δ − S/βR);\nFedAvg per model")]
for x, txt in boxes:
    ax.add_patch(FancyBboxPatch((x, 0.75), 1.75, 1.45, boxstyle="round,pad=0.02,rounding_size=0.08",
                                fc="#eef4fc" if "Dual" in txt or "Primal" in txt else "#f6f5f2", ec=MUTED, lw=0.8))
    ax.text(x + 0.875, 1.475, txt, ha="center", va="center", fontsize=8, color=INK)
for x in [1.85, 3.8, 5.75, 7.7]:
    ax.annotate("", xy=(x + 0.2, 1.475), xytext=(x, 1.475), arrowprops=dict(arrowstyle="-|>", color=MUTED, lw=1))
ax.plot([8.775, 8.775, 2.925], [0.75, 0.45, 0.45], color="#2a78d6", lw=1.2)
ax.annotate("", xy=(2.925, 0.75), xytext=(2.925, 0.45), arrowprops=dict(arrowstyle="-|>", color="#2a78d6", lw=1.2))
ax.text(5.85, 0.18, "Queue update: Q ← max{Q + (E − ē)/ē, 0},  Z ← max{Z + c_Z (r_min − x), 0}", ha="center", fontsize=8, color="#1c5cab")
fig.savefig("fig1_flow.png")
print("ok")
