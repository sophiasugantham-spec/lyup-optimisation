"""Experiment driver. Usage: python3 exp.py <suite> [workers]
Each job's summarized result is saved to results/<suite>/<tag>.pkl"""
import os, sys, pickle, time, itertools
import numpy as np
from multiprocessing import Pool
from sim import run
from metrics import summarize

METHODS = ["LyMM-FL", "HD-MMFL", "Oort", "FedCS", "Greedy", "MM-Assign", "Random"]


def jobs(suite):
    J = []
    if suite == "main":
        for seed in range(10):
            for m in METHODS:
                J.append((f"{m}_s{seed}", dict(policy_name=m, seed=seed, N=50, T=200)))
    elif suite == "ablation":
        variants = {"full": {}, "noQ": dict(use_energy_q=False), "noZ": dict(use_fair_q=False),
                    "noDVFS": dict(dvfs=False), "eqBW": dict(opt_bw=False),
                    "myopic": dict(use_energy_q=False, use_fair_q=False)}
        for seed in range(5):
            for v, kw in variants.items():
                J.append((f"{v}_s{seed}", dict(policy_name="LyMM-FL", seed=seed, N=50, T=200, policy_kw=kw)))
    elif suite == "tradeoff":
        for seed in range(3):
            for V in [0.1, 0.3, 1, 3, 10]:
                J.append((f"V{V}_s{seed}", dict(policy_name="LyMM-FL", seed=seed, N=50, T=200, pol_cfg={"V": V})))
            for r in [0.0, 0.05, 0.15, 0.2]:
                J.append((f"r{r}_s{seed}", dict(policy_name="LyMM-FL", seed=seed, N=50, T=200, pol_cfg={"rmin": r})))
    elif suite == "robust":
        for seed in range(3):
            for m in ["LyMM-FL", "HD-MMFL", "Oort", "Random"]:
                for al in [0.25, 1.0]:
                    J.append((f"allow{al}_{m}_s{seed}", dict(policy_name=m, seed=seed, N=50, T=200,
                                                              sys_cfg={"allowance": al})))
                for da in [0.1, 1.0]:
                    J.append((f"dir{da}_{m}_s{seed}", dict(policy_name=m, seed=seed, N=50, T=200,
                                                            sys_cfg={"dir_alpha": da})))
    elif suite == "cifar":
        for seed in range(3):
            for m in ["LyMM-FL", "HD-MMFL", "Oort", "Random"]:
                J.append((f"{m}_s{seed}", dict(policy_name=m, seed=seed, N=50, T=120, sys_cfg={"scenario": "gateway"})))
    elif suite == "scale":
        for seed in range(3):
            for N in [20, 50, 100, 200, 500, 1000]:
                for m in METHODS:
                    J.append((f"N{N}_{m}_s{seed}", dict(policy_name=m, seed=seed, N=N, T=40, train=False,
                                                         sys_cfg={"bandwidth": 1e6 * N / 50}, record_gap=True)))
    return J


def work(args):
    suite, tag, kw = args
    out = f"results/{suite}/{tag}.pkl"
    if os.path.exists(out):
        return tag
    t0 = time.time()
    kw.setdefault("record_gap", True)
    L = run(**kw)
    s = summarize(L)
    s["acc_curve"] = L["acc"]
    s["acc_rounds"] = L["acc_rounds"]
    s["energy_curve"] = L["energy"].mean(1)
    s["ok_curve"] = L["ok"].any(2).sum(1)
    s["runtime_all"] = L["runtime"]
    s["gap_all"] = L["gap"]
    s["part"] = L["ok"].mean(0)
    s["eligible"] = L["eligible"]
    s["avgE_over_ebar"] = L["energy"].mean(0) / L["hbar"]
    s["fail_deadline"] = L["fail_deadline"].sum()
    s["fail_battery"] = L["fail_battery"].sum()
    s["selected"] = L["x"].any(2).sum()
    s["wall"] = time.time() - t0
    with open(out, "wb") as f:
        pickle.dump(s, f)
    return tag


if __name__ == "__main__":
    suite = sys.argv[1]
    workers = int(sys.argv[2]) if len(sys.argv) > 2 else 2
    os.makedirs(f"results/{suite}", exist_ok=True)
    J = [(suite, t, k) for t, k in jobs(suite)]
    # longest first
    J.sort(key=lambda j: -(j[2].get("N", 50) * (3 if j[2]["policy_name"].startswith("LyMM") else 1)))
    with Pool(workers) as p:
        for i, tag in enumerate(p.imap_unordered(work, J)):
            print(f"{i + 1}/{len(J)} {tag}", flush=True)
