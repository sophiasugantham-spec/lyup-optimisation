"""Selection/scheduling policies. Each returns a plan: dict device -> (mask[K], beta, f)."""
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
from solver import RoundProblem, solve_round, energy_of_beta


def _plan_from_opts(prob, opts, beta):
    plan = {}
    for j, b in zip(opts, beta):
        i = prob.dev[j]
        C, S = prob.C[j], prob.S[j]
        tau = S / (b * prob.Rv[j])
        f = C / (prob.D - tau) if C > 0 else 0.0
        plan[i] = (prob.mask[j].copy(), float(b), float(f))
    return plan


def equal_share_plan(sysm, sel_masks, avail):
    """Baseline execution: equal bandwidth among selected devices, CPU at fmax."""
    devs = [i for i, m in sel_masks.items() if m.any()]
    if not devs:
        return {}
    b = 1.0 / len(devs)
    return {i: (sel_masks[i], b, sysm.fmax[i]) for i in devs}


class Policy:
    name = "base"

    def __init__(self, sysm, cfg, rng):
        self.sysm, self.cfg, self.rng = sysm, cfg, rng
        self.last_runtime = 0.0
        self.last_gap = None

    def observe(self, t, plan, success, energy, utility):
        pass


# ----------------------------------------------------------------------------- proposed
class LyMMFL(Policy):
    """Lyapunov drift-plus-penalty with energy queues Q_i and fairness queues Z_ik."""
    name = "LyMM-FL"

    def __init__(self, sysm, cfg, rng, V=None, gamma=None, rmin=None, use_energy_q=True,
                 use_fair_q=True, dvfs=True, opt_bw=True, cz=None):
        super().__init__(sysm, cfg, rng)
        self.cz = cfg.get("cz", 1.0) if cz is None else cz  # weight of the fairness queues
        self.V = cfg["V"] if V is None else V
        self.gamma = cfg["gamma"] if gamma is None else gamma
        self.rmin = cfg["rmin"] if rmin is None else rmin
        self.Q = np.zeros(sysm.N)  # normalised energy-deficit queues
        self.Z = np.zeros((sysm.N, sysm.K))
        self.use_energy_q, self.use_fair_q = use_energy_q, use_fair_q
        self.dvfs, self.opt_bw = dvfs, opt_bw

    def plan(self, t, avail, R, util, battery):
        s = self.sysm
        theta = self.V * util + (self.Z if self.use_fair_q else 0.0)
        omega = (self.V * self.gamma + (self.Q if self.use_energy_q else 0.0)) / s.ebar  # normalised energy
        prob = RoundProblem(s, avail, R, theta, omega, battery)
        res = solve_round(prob)
        self.last_gap = (res["ub"] - res["obj"]) / max(abs(res["ub"]), 1e-12)
        self.last_prob, self.last_res = prob, res
        plan = _plan_from_opts(prob, res["opts"], res["beta"])
        if not self.dvfs:  # ablation: run at fmax
            plan = {i: (m, b, s.fmax[i]) for i, (m, b, f) in plan.items()}
        if not self.opt_bw:  # ablation: equal bandwidth share among the selected devices
            plan = equal_share_plan(s, {i: m for i, (m, b, f) in plan.items()}, avail)
        return plan

    def observe(self, t, plan, success, energy, utility):
        s = self.sysm
        x = np.zeros((s.N, s.K))
        for i, (m, b, f) in plan.items():
            x[i] = m
        self.Q = np.maximum(self.Q + (energy - s.ebar) / s.ebar, 0.0)
        self.Z = np.maximum(self.Z + self.cz * (self.rmin * s.a - x * s.a), 0.0)


# ----------------------------------------------------------------------------- baselines
class RandomSel(Policy):
    """Each available (device, model) pair joins with probability q; equal share, fmax."""
    name = "Random"

    def plan(self, t, avail, R, util, battery):
        s = self.sysm
        q = self.cfg["random_q"]
        sel = {}
        for i in np.where(avail)[0]:
            m = (s.a[i] > 0) & (self.rng.random(s.K) < q)
            if m.any():
                sel[i] = m
        return equal_share_plan(s, sel, avail)


class SingleModelAssign(Policy):
    """Multi-model assignment in the spirit of Bhuyan & Moharir (2022): every available device
    trains exactly one of its models per round, chosen uniformly; equal share, fmax."""
    name = "MM-Assign"

    def plan(self, t, avail, R, util, battery):
        s = self.sysm
        q = self.cfg["assign_q"]
        sel = {}
        for i in np.where(avail)[0]:
            if self.rng.random() > q:
                continue
            ks = np.where(s.a[i])[0]
            if len(ks) == 0:
                continue
            m = np.zeros(s.K, bool)
            m[self.rng.choice(ks)] = True
            sel[i] = m
        return equal_share_plan(s, sel, avail)


class GreedyData(Policy):
    """Largest local datasets first (all of a device's models), until the
    equal-share deadline estimate fails; fmax. Ignores energy and fairness."""
    name = "Greedy"

    def plan(self, t, avail, R, util, battery):
        s = self.sysm
        devs = [i for i in np.where(avail)[0]]
        devs.sort(key=lambda i: -s.n[i].sum())
        chosen = []
        for i in devs:
            trial = chosen + [i]
            b = 1.0 / len(trial)
            ok = True
            for j in trial:
                C = s.cycles[j][s.a[j] > 0].sum()
                S = s.s[s.a[j] > 0].sum()
                if C / s.fmax[j] + S / (b * R[j]) > s.Delta:
                    ok = False
                    break
            if ok:
                chosen = trial
        return equal_share_plan(s, {i: s.a[i] > 0 for i in chosen}, avail)


class FedCS(Policy):
    """FedCS (Nishio & Yonetani 2019) adapted: add devices in order of shortest estimated
    completion time while all selected devices still meet the deadline with the minimum
    bandwidth they need; leftover bandwidth split equally; fmax."""
    name = "FedCS"

    def plan(self, t, avail, R, util, battery):
        s = self.sysm
        cand = []
        for i in np.where(avail)[0]:
            m = s.a[i] > 0
            C, S = s.cycles[i][m].sum(), s.s[m].sum()
            slack = s.Delta - C / s.fmax[i]
            if slack <= 0:
                continue
            bmin = S / (R[i] * slack)
            cand.append((C / s.fmax[i] + S / R[i], i, m, bmin))
        cand.sort()
        sel, used = [], 0.0
        for _, i, m, bmin in cand:
            if used + bmin <= 1.0:
                sel.append((i, m, bmin))
                used += bmin
        if not sel:
            return {}
        extra = (1.0 - used) / len(sel)
        return {i: (m, bmin + extra, s.fmax[i]) for i, m, bmin in sel}


class OortSel(Policy):
    """Oort-style guided selection (Lai et al. 2021): statistical utility x deadline penalty,
    top-M per model with epsilon exploration; equal share, fmax."""
    name = "Oort"

    def plan(self, t, avail, R, util, battery):
        s = self.sysm
        M = self.cfg["oort_M"]
        eps = self.cfg["oort_eps"]
        nav = max(int(avail.sum()), 1)
        sel = {}
        for k in range(s.K):
            idx = [i for i in np.where(avail)[0] if s.a[i, k]]
            if not idx:
                continue
            score = []
            for i in idx:
                tt = s.cycles[i, k] / s.fmax[i] + s.s[k] / (R[i] / nav)
                pen = (s.Delta / tt) ** 2 if tt > s.Delta else 1.0
                score.append(util[i, k] * pen)
            order = list(np.array(idx)[np.argsort(-np.array(score))])
            n_exploit = int(round((1 - eps) * M))
            pick = order[:n_exploit]
            rest = order[n_exploit:]
            if rest:
                pick += list(self.rng.choice(rest, min(M - n_exploit, len(rest)), replace=False))
            for i in pick:
                sel.setdefault(i, np.zeros(s.K, bool))[k] = True
        return equal_share_plan(s, sel, avail)


class HDMMFL(Policy):
    """The authors' earlier per-round method: an ILP maximising utility minus weighted
    time/energy costs (estimated at fmax and an equal share among available devices),
    with per-round battery and time caps and a cumulative participation cap; then
    equal-share execution at fmax."""
    name = "HD-MMFL"

    def __init__(self, sysm, cfg, rng):
        super().__init__(sysm, cfg, rng)
        self.count = np.zeros((sysm.N, sysm.K))

    def plan(self, t, avail, R, util, battery):
        s = self.sysm
        nav = max(int(avail.sum()), 1)
        al, be, ga = self.cfg["hd_weights"]
        pairs = [(i, k) for i in np.where(avail)[0] for k in range(s.K) if s.a[i, k]]
        if not pairs:
            return {}
        n = len(pairs)
        Tc = np.array([s.cycles[i, k] / s.fmax[i] for i, k in pairs])
        Tu = np.array([s.s[k] / (R[i] / nav) for i, k in pairs])
        E = np.array([s.kappa[i] * s.cycles[i, k] * s.fmax[i] ** 2 + s.p[i] * s.s[k] / (R[i] / nav)
                      for i, k in pairs])
        u = np.array([util[i, k] for i, k in pairs])
        c = -(u - al * Tu - be * Tc - ga * E)
        A, lb, ub = [], [], []
        devs = sorted(set(i for i, _ in pairs))
        for i in devs:
            row_e = np.array([E[j] if pairs[j][0] == i else 0 for j in range(n)])
            row_t = np.array([Tc[j] + Tu[j] if pairs[j][0] == i else 0 for j in range(n)])
            A += [row_e, row_t]
            lb += [-np.inf, -np.inf]
            ub += [battery[i], s.Delta]
        qmax = np.ceil(self.cfg["hd_qmax"] * (t + 1))
        xub = np.array([1.0 if self.count[i, k] + 1 <= qmax else 0.0 for i, k in pairs])
        res = milp(c, integrality=np.ones(n), bounds=Bounds(np.zeros(n), xub),
                   constraints=LinearConstraint(np.array(A), lb, ub))
        sel = {}
        if res.x is not None:
            for j, (i, k) in enumerate(pairs):
                if res.x[j] > 0.5:
                    sel.setdefault(i, np.zeros(s.K, bool))[k] = True
        return equal_share_plan(s, sel, avail)

    def observe(self, t, plan, success, energy, utility):
        for i, (m, b, f) in plan.items():
            self.count[i] += m


ALL_POLICIES = {
    "LyMM-FL": LyMMFL, "HD-MMFL": HDMMFL, "Oort": OortSel, "FedCS": FedCS,
    "Greedy": GreedyData, "MM-Assign": SingleModelAssign, "Random": RandomSel,
}
