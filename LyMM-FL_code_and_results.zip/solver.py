"""Per-round solver of LyMM-FL: dual decomposition over the shared-bandwidth constraint.

Per-round problem P1(t):
    max_{x,beta,f}  sum_i [ sum_k x_ik theta_ik  - omega_i * E_i ]
    s.t. sum_i beta_i <= 1,  deadline, battery, f_i <= fmax_i, x_ik <= a_ik * avail_i
For a device with workload (C,S) and share beta, the optimal frequency is the slowest one that
meets the deadline, f = C / (Delta - S/(beta R)), which gives the convex energy
    e(beta) = kappa C^3 / (Delta - S/(beta R))^2 + p S / (beta R).
Everything below is vectorised over candidate (device, subset) options.
"""
import itertools
import numpy as np

NB = 32  # bisection steps (relative precision ~2e-10)


def energy_of_beta(beta, C, S, R, kappa, p, Delta):
    tau = np.where(S > 0, S / np.maximum(beta * R, 1e-30), 0.0)
    tc = Delta - tau
    ecmp = np.where(C > 0, kappa * C ** 3 / np.maximum(tc, 1e-30) ** 2, 0.0)
    return ecmp + p * tau


def denergy_dbeta(beta, C, S, R, kappa, p, Delta):
    tau = np.where(S > 0, S / np.maximum(beta * R, 1e-30), 0.0)
    tc = np.maximum(Delta - tau, 1e-30)
    de_dtau = np.where(C > 0, 2 * kappa * C ** 3 / tc ** 3, 0.0) + p
    return -(tau / np.maximum(beta, 1e-30)) * de_dtau


def beta_lower(C, S, R, kappa, p, Delta, fmax, battery):
    """Smallest feasible share (deadline at fmax, and battery). inf if infeasible."""
    tcmin = np.where(C > 0, C / fmax, 0.0)
    slack = Delta - tcmin
    with np.errstate(divide="ignore", invalid="ignore"):
        bdl = np.where(S > 0, S / (R * np.maximum(slack, 1e-30)), 0.0)
    bdl = np.where(slack <= 0, np.inf, bdl)
    bdl = np.maximum(bdl, 1e-9)
    feas = bdl <= 1.0
    e1 = energy_of_beta(np.ones_like(bdl), C, S, R, kappa, p, Delta)
    feas &= e1 <= battery
    # battery: e(beta) decreasing -> bisection for smallest beta with e <= battery
    lo, hi = bdl.copy(), np.ones_like(bdl)
    ok_lo = energy_of_beta(np.minimum(lo, 1.0), C, S, R, kappa, p, Delta) <= battery
    for _ in range(NB):
        mid = 0.5 * (lo + hi)
        good = energy_of_beta(mid, C, S, R, kappa, p, Delta) <= battery
        hi = np.where(good, mid, hi)
        lo = np.where(good, lo, mid)
    bb = np.where(ok_lo, bdl, hi)
    # tiny margin so that f <= fmax holds numerically
    bb = np.minimum(bb * (1 + 1e-6), 1.0)
    return np.where(feas, bb, np.inf)


def best_beta(mu, omega, C, S, R, kappa, p, Delta, blo):
    """argmin_{blo<=beta<=1} omega e(beta) + mu beta  (convex, 1-D)."""
    blo_c = np.minimum(blo, 1.0)
    d_lo = omega * denergy_dbeta(blo_c, C, S, R, kappa, p, Delta) + mu
    d_hi = omega * denergy_dbeta(np.ones_like(blo_c), C, S, R, kappa, p, Delta) + mu
    lo, hi = blo_c.copy(), np.ones_like(blo_c)
    for _ in range(NB):
        mid = 0.5 * (lo + hi)
        d = omega * denergy_dbeta(mid, C, S, R, kappa, p, Delta) + mu
        hi = np.where(d > 0, mid, hi)
        lo = np.where(d > 0, lo, mid)
    b = 0.5 * (lo + hi)
    b = np.where(d_lo >= 0, blo_c, b)
    b = np.where(d_hi <= 0, 1.0, b)
    return b


class RoundProblem:
    """Builds the candidate options (device, subset of its available models)."""

    def __init__(self, sysm, avail, R, theta, omega, battery, max_subset_models=None):
        N, K = sysm.N, sysm.K
        self.sysm, self.N, self.K = sysm, N, K
        opts_dev, opts_mask = [], []
        for i in range(N):
            if not avail[i]:
                continue
            ks = [k for k in range(K) if sysm.a[i, k]]
            for r in range(1, len(ks) + 1):
                for sub in itertools.combinations(ks, r):
                    m = np.zeros(K, bool)
                    m[list(sub)] = True
                    opts_dev.append(i)
                    opts_mask.append(m)
        self.dev = np.array(opts_dev, int)
        self.mask = np.array(opts_mask, bool).reshape(-1, K)
        d = self.dev
        self.C = (sysm.cycles[d] * self.mask).sum(1)
        self.S = (sysm.s[None, :] * self.mask).sum(1)
        self.Rv = R[d]
        self.kap = sysm.kappa[d]
        self.p = sysm.p[d]
        self.D = sysm.Delta
        self.gain = (theta[d] * self.mask).sum(1)
        self.omega = omega[d]
        self.blo = beta_lower(self.C, self.S, self.Rv, self.kap, self.p, self.D, sysm.fmax[d], battery[d])
        keep = np.isfinite(self.blo)
        for name in ["dev", "mask", "C", "S", "Rv", "kap", "p", "gain", "omega", "blo"]:
            setattr(self, name, getattr(self, name)[keep])

    def option_values(self, mu):
        b = best_beta(mu, self.omega, self.C, self.S, self.Rv, self.kap, self.p, self.D, self.blo)
        e = energy_of_beta(b, self.C, self.S, self.Rv, self.kap, self.p, self.D)
        val = self.gain - self.omega * e - mu * b
        return val, b, e

    def per_device_choice(self, mu):
        """For each device choose its best option (or none). Returns option index per device (-1=none)."""
        val, b, e = self.option_values(mu)
        choice = -np.ones(self.N, int)
        best = np.zeros(self.N)
        if len(val):
            order = np.lexsort((-val, self.dev))
            d_sorted = self.dev[order]
            first = np.r_[True, d_sorted[1:] != d_sorted[:-1]]
            top = order[first]
            pos = val[top] > 0
            choice[self.dev[top[pos]]] = top[pos]
            best[self.dev[top[pos]]] = val[top[pos]]
        return choice, best, b, e

    def dual(self, mu):
        _, best, b, _ = self.per_device_choice(mu)
        return best.sum() + mu

    def allocate(self, opts, nu_hint=None):
        """Optimal bandwidth for a fixed set of options: min sum omega e(beta) s.t. sum beta<=1."""
        opts = np.asarray(opts, int)
        if len(opts) == 0:
            return np.zeros(0), 0.0, True
        sl = lambda a: a[opts]
        args = (sl(self.C), sl(self.S), sl(self.Rv), sl(self.kap), sl(self.p), self.D)
        blo = sl(self.blo)
        if blo.sum() > 1.0 + 1e-9:
            return None, None, False
        om = sl(self.omega)

        def betas(nu):
            return best_beta(nu, np.maximum(om, 1e-9), *args, blo)

        if betas(0.0).sum() <= 1.0:
            b = betas(0.0)
        else:
            lo, hi = 0.0, (nu_hint if nu_hint else 1.0)
            while betas(hi).sum() > 1.0:
                lo = hi
                hi *= 2
            for _ in range(24):
                mid = 0.5 * (lo + hi)
                if betas(mid).sum() > 1.0:
                    lo = mid
                else:
                    hi = mid
            b = betas(hi)
        e = energy_of_beta(b, *args)
        obj = (sl(self.gain) - om * e).sum()
        return b, obj, True


def solve_round(prob, n_improve=10):
    """Dual decomposition + primal recovery + greedy improvement. Returns dict."""
    if len(prob.dev) == 0:
        return dict(opts=[], beta=np.zeros(0), obj=0.0, ub=0.0)

    def tot_beta(mu):
        ch, _, b, _ = prob.per_device_choice(mu)
        sel = ch[ch >= 0]
        return b[sel].sum()

    lo, hi = 0.0, 1.0
    if tot_beta(0.0) <= 1.0:
        hi = 0.0
    else:
        while tot_beta(hi) > 1.0:
            hi *= 4
        for _ in range(30):
            mid = 0.5 * (lo + hi)
            if tot_beta(mid) > 1.0:
                lo = mid
            else:
                hi = mid
    ub = min(prob.dual(hi), prob.dual(lo) if lo > 0 else np.inf, prob.dual(0.5 * (lo + hi)))
    # primal recovery from the feasible side
    ch, _, _, _ = prob.per_device_choice(hi)
    cur = {prob.dev[j]: j for j in ch if j >= 0}
    b, obj, ok = prob.allocate(list(cur.values()), nu_hint=max(hi, 1e-12))
    if not ok:  # should not happen; drop worst until feasible
        while not ok and cur:
            worst = min(cur, key=lambda i: prob.gain[cur[i]])
            cur.pop(worst)
            b, obj, ok = prob.allocate(list(cur.values()))
    # greedy improvement using options preferred at the infeasible side
    if lo > 0 and n_improve > 0:
        val, _, _ = prob.option_values(lo)
        cand = np.argsort(-val)[: n_improve * 3]
        tried = 0
        for j in cand:
            if tried >= n_improve:
                break
            i = prob.dev[j]
            if cur.get(i) == j or val[j] <= 0:
                continue
            tried += 1
            trial = dict(cur)
            trial[i] = j
            b2, obj2, ok2 = prob.allocate(list(trial.values()), nu_hint=max(lo, 1e-12))
            if ok2 and obj2 > obj + 1e-12:
                cur, b, obj = trial, b2, obj2
    ub = max(ub, obj)
    return dict(opts=list(cur.values()), beta=b, obj=obj, ub=ub)


def brute_force(prob):
    """Exact optimum of P1 by enumerating every option combination (small N only)."""
    devs = sorted(set(prob.dev.tolist()))
    per = [[-1] + [j for j in range(len(prob.dev)) if prob.dev[j] == i] for i in devs]
    best = 0.0
    for combo in itertools.product(*per):
        opts = [j for j in combo if j >= 0]
        if not opts:
            continue
        if prob.blo[opts].sum() > 1.0:
            continue
        _, obj, ok = prob.allocate(opts)
        if ok and obj > best:
            best = obj
    return best
