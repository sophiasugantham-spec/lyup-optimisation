"""Optimality gap of the per-round solver against exhaustive enumeration (small N)."""
import itertools, pickle, sys, time
import numpy as np
from env import build_tasks, EdgeSystem, DEFAULT_CFG
from solver import RoundProblem, solve_round, best_beta, energy_of_beta


def exact(prob):
    devs = sorted(set(prob.dev.tolist()))
    per = [[-1] + [j for j in range(len(prob.dev)) if prob.dev[j] == i] for i in devs]
    combos = np.array(list(itertools.product(*per)))  # M x n_dev, -1 = not selected
    M, nd = combos.shape
    sel = combos >= 0
    idx = np.where(sel, combos, 0)

    def g(a):
        return np.where(sel, a[idx], 0.0)

    C, S, R, kap, p = g(prob.C), g(prob.S), np.where(sel, prob.Rv[idx], 1.0), g(prob.kap), g(prob.p)
    om, blo, gain = g(prob.omega), g(prob.blo), g(prob.gain)
    feas = blo.sum(1) <= 1.0
    D = prob.D

    def betas(nu):
        b = best_beta(nu[:, None], np.maximum(om, 1e-9), C, S, R, kap, p, D, blo)
        return np.where(sel, b, 0.0)

    b0 = betas(np.zeros(M))
    need = b0.sum(1) > 1.0
    lo, hi = np.zeros(M), np.ones(M)
    for _ in range(60):  # expand
        over = need & (betas(hi).sum(1) > 1.0)
        if not over.any():
            break
        lo = np.where(over, hi, lo)
        hi = np.where(over, hi * 2, hi)
    for _ in range(40):
        mid = 0.5 * (lo + hi)
        over = betas(mid).sum(1) > 1.0
        lo = np.where(over, mid, lo)
        hi = np.where(over, hi, mid)
    b = np.where(need[:, None], betas(hi), b0)
    e = np.where(sel, energy_of_beta(np.maximum(b, 1e-12), C, S, R, kap, p, D), 0.0)
    obj = (gain - om * e).sum(1)
    obj = np.where(feas, obj, -np.inf)
    return max(obj.max(), 0.0)


def instance(seed, N=6):
    rng = np.random.default_rng(seed)
    cfg = dict(DEFAULT_CFG, bandwidth=rng.uniform(0.6e5, 1.6e5))
    tasks, a = build_tasks(N, rng)
    s = EdgeSystem(N, tasks, a, rng, cfg)
    avail, R, _ = s.draw_round(rng)
    avail[:] = True
    V = 1.0
    theta = (V * rng.random((N, s.K)) + rng.uniform(0, 5, (N, s.K))) * s.a
    omega = (V * 0.02 + rng.uniform(0, 20, N)) / s.ebar
    battery = rng.uniform(0.1, 1.0, N)
    return RoundProblem(s, avail, R, theta, omega, battery)


if __name__ == "__main__":
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 100
    N = int(sys.argv[2]) if len(sys.argv) > 2 else 6
    rows = []
    for sd in range(n):
        prob = instance(sd, N)
        t0 = time.perf_counter()
        r = solve_round(prob)
        t1 = time.perf_counter()
        opt = exact(prob)
        t2 = time.perf_counter()
        rows.append(dict(seed=sd, heur=r["obj"], ub=r["ub"], opt=opt, t_heur=t1 - t0, t_exact=t2 - t1,
                         n_opts=len(prob.dev)))
        print(sd, round(r["obj"], 4), round(opt, 4), round(r["ub"], 4), f"{t1 - t0:.3f}s {t2 - t1:.2f}s", flush=True)
    pickle.dump(rows, open(f"results/gap_N{N}.pkl", "wb"))
