import pickle, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
exec(open("figs_main.py").read().split("R = {m:")[0])
M=["LyMM-FL","HD-MMFL","Oort","Random"]
R={m:[pickle.load(open(f"results/cifar/{m}_s{s}.pkl","rb")) for s in range(3)] for m in M}
fig,axs=plt.subplots(1,2,figsize=(9,3.0))
ax=axs[0]
for m in M:
    A=np.array([r["acc_curve"][:,3] for r in R[m]])*100; x=R[m][0]["acc_rounds"]
    ax.plot(x,A.mean(0),color=COL[m],lw=2.2 if m=="LyMM-FL" else 1.3,label=m)
    if m=="LyMM-FL": ax.fill_between(x,A.mean(0)-A.std(0),A.mean(0)+A.std(0),color=COL[m],alpha=0.12,lw=0)
ax.set_xlabel("Round"); ax.set_ylabel("Test accuracy (%)"); ax.set_title("(a) CIFAR-10 CNN accuracy",fontsize=9,color=INK); ax.legend(fontsize=7.5)
ax=axs[1]
v=np.array([[r["avgE_over_ebar"].max() for r in R[m]] for m in M]); y=np.arange(len(M))
ax.barh(y,v.mean(1),xerr=v.std(1,ddof=1),color=[COL[m] for m in M],height=0.6,error_kw=dict(ecolor=MUTED,lw=0.8))
ax.axvline(1,color=INK,lw=1,ls="--"); ax.set_yticks(y,M); ax.invert_yaxis(); ax.grid(axis="y",visible=False)
for yi,mu,sd in zip(y,v.mean(1),v.std(1,ddof=1)): ax.text(mu+sd+0.06,yi,f"{mu:.2f}",va="center",fontsize=7.5,color=INK)
ax.set_xlabel("ratio (1 = on budget)"); ax.set_title("(b) Worst device: avg energy / allowance",fontsize=9,color=INK)
fig.tight_layout(); fig.savefig("fig7_cifar.png"); print("ok")
