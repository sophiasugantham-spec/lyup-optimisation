import pickle, glob, numpy as np, json
from scipy.stats import wilcoxon
M=["LyMM-FL","HD-MMFL","Oort","FedCS","Greedy","MM-Assign","Random"]
R={m:[pickle.load(open(f"results/main/{m}_s{s}.pkl","rb")) for s in range(10)] for m in M}
def col(m,f): return np.array([f(r) for r in R[m]])
metrics={
 "acc_digits":lambda r:r["last_acc"][0]*100,"acc_syn":lambda r:r["last_acc"][1]*100,"acc_bc":lambda r:r["last_acc"][2]*100,
 "acc_mean":lambda r:r["last_acc"].mean()*100,"acc_min":lambda r:r["last_acc"].min()*100,
 "E_mJ":lambda r:r["E_mean"]*1e3,"over":lambda r:r["frac_over"]*100,"worst_ratio":lambda r:r["avgE_over_ebar"].max(),
 "fail":lambda r:r["fail_rate"]*100,"depleted":lambda r:r["depleted"],
 "minpart":lambda r:r["minpart"],"below":lambda r:r["frac_below"]*100,"jain":lambda r:r["jain"],
 "ok":lambda r:r["ok"],"runtime_ms":lambda r:r["runtime"]*1e3,"gap":lambda r:np.nanmean(r["gap_all"])*100,
 "gap_max":lambda r:np.nanmax(r["gap_all"])*100 if np.isfinite(r["gap_all"]).any() else np.nan,
 "acc_per_J":lambda r: r["last_acc"].mean()/(r["E_mean"]*1e3),
 "elig_all":lambda r: float(r["eligible"].sum()==r["n_pairs"]),
}
out={}
for k,f in metrics.items():
    line=f"{k:12s}"
    base=col("LyMM-FL",f)
    for m in M:
        v=col(m,f); out.setdefault(m,{})[k]=(float(np.nanmean(v)),float(np.nanstd(v,ddof=1)))
        p=""
        if m!="LyMM-FL" and k not in("gap","gap_max","elig_all") and np.any(v!=base):
            try: p=f" p={wilcoxon(base,v).pvalue:.3f}"
            except Exception: p=""
        line+=f" | {m}: {np.nanmean(v):.3f}±{np.nanstd(v,ddof=1):.3f}{p}"
    print(line)
json.dump(out,open("results/main_summary.json","w"),indent=1)
