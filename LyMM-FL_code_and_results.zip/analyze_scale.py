import pickle, numpy as np
M=["LyMM-FL","HD-MMFL","Oort","FedCS","Greedy","MM-Assign","Random"]
Ns=[20,50,100,200,500,1000]
out={}
for m in M:
    for N in Ns:
        R=[pickle.load(open(f"results/scale/N{N}_{m}_s{s}.pkl","rb")) for s in range(3)]
        rt=np.array([r["runtime"] for r in R])*1e3
        g=np.array([np.nanmean(r["gap_all"]) for r in R])*100
        gm=np.array([np.nanmax(r["gap_all"]) if np.isfinite(r["gap_all"]).any() else np.nan for r in R])*100
        out[(m,N)]=dict(rt=rt.mean(), rt_sd=rt.std(), gap=np.nanmean(g), gapmax=np.nanmax(gm) if np.isfinite(gm).any() else np.nan,
            fail=np.mean([r["fail_rate"] for r in R])*100, ok=np.mean([r["ok"] for r in R]), over=np.mean([r["frac_over"] for r in R])*100,
            worst=np.mean([r["avgE_over_ebar"].max() for r in R]))
for m in M:
    print(m.ljust(10), " ".join(f"N{N}:{out[(m,N)]['rt']:.1f}ms" for N in Ns))
for N in Ns:
    o=out[("LyMM-FL",N)]; print(N, "gap mean %.4f%% max %.3f%%"%(o["gap"],o["gapmax"]), "ok/rnd %.1f"%o["ok"], "fail", {m:round(out[(m,N)]['fail'],1) for m in M})
pickle.dump(out,open("results/scale_summary.pkl","wb"))
