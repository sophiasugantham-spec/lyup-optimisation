import pickle, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
exec(open("figs_main.py").read().split("R = {m:")[0])
out=pickle.load(open("results/scale_summary.pkl","rb")); Ns=[20,50,100,200,500,1000]
fig,axs=plt.subplots(1,2,figsize=(8.6,3.0))
ax=axs[0]
for m in ["LyMM-FL","HD-MMFL","Greedy","FedCS"]:
    y=[out[(m,N)]["rt"] for N in Ns]
    ax.plot(Ns,y,"-o",color=COL[m],lw=2.2 if m=="LyMM-FL" else 1.3,ms=4,label=m)
ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlabel("Devices N (bandwidth scaled with N)"); ax.set_ylabel("Planning time per round (ms)")
ax.set_title("(a) Solver run time",fontsize=9,color=INK); ax.legend(fontsize=7.5)
ax=axs[1]
g=[out[("LyMM-FL",N)]["gap"] for N in Ns]; gm=[out[("LyMM-FL",N)]["gapmax"] for N in Ns]
ax.plot(Ns,g,"-o",color=COL["LyMM-FL"],lw=2.2,ms=4,label="mean over rounds")
ax.plot(Ns,gm,"--o",color="#1c5cab",lw=1.3,ms=4,label="worst round")
ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlabel("Devices N"); ax.set_ylabel("Relative certificate δ(t)/UB (%)")
ax.set_title("(b) Per-round optimality certificate",fontsize=9,color=INK); ax.legend(fontsize=7.5)
fig.tight_layout(); fig.savefig("fig5_scale.png"); print("ok")
