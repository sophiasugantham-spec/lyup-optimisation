"""Small CNN for CIFAR-10 in NumPy (im2col), with the same interface as env.py models.
conv(3->8, 5x5) - ReLU - maxpool2 - conv(8->16, 5x5) - ReLU - maxpool2 - fc(400->10)
"""
import pickle, os
import numpy as np


def im2col(x, k):
    # x: (n, c, h, w) -> (n, oh, ow, c*k*k)
    n, c, h, w = x.shape
    oh, ow = h - k + 1, w - k + 1
    s = x.strides
    cols = np.lib.stride_tricks.as_strided(x, (n, oh, ow, c, k, k), (s[0], s[2], s[3], s[1], s[2], s[3]))
    return cols.reshape(n, oh, ow, c * k * k)


def col2im(dcols, xshape, k):
    n, c, h, w = xshape
    oh, ow = h - k + 1, w - k + 1
    d = dcols.reshape(n, oh, ow, c, k, k)
    dx = np.zeros(xshape, dcols.dtype)
    for i in range(k):
        for j in range(k):
            dx[:, :, i:i + oh, j:j + ow] += d[:, :, :, :, i, j].transpose(0, 3, 1, 2)
    return dx


def pool_fw(a):
    n, c, h, w = a.shape
    r = a.reshape(n, c, h // 2, 2, w // 2, 2)
    m = r.max(axis=(3, 5))
    mask = (r == m[:, :, :, None, :, None])
    return m, mask


def pool_bw(dm, mask):
    d = mask * dm[:, :, :, None, :, None]
    n, c, h2, _, w2, _ = d.shape
    return d.reshape(n, c, h2 * 2, w2 * 2)


class CNNModel:
    def __init__(self, c1=8, c2=16):
        self.c1, self.c2 = c1, c2
        self.n_params = 3 * 25 * c1 + c1 + c1 * 25 * c2 + c2 + c2 * 25 * 10 + 10
        # forward FLOPs per sample (multiply-adds x2): conv1 28x28, conv2 10x10, fc
        fw = 2 * (28 * 28 * c1 * 75 + 10 * 10 * c2 * c1 * 25 + c2 * 25 * 10)
        self.train_flops_per_sample = 3 * fw  # forward + backward

    def init(self, rng):
        c1, c2 = self.c1, self.c2
        return [rng.normal(0, np.sqrt(2 / 75), (75, c1)).astype(np.float32), np.zeros(c1, np.float32),
                rng.normal(0, np.sqrt(2 / (25 * c1)), (25 * c1, c2)).astype(np.float32), np.zeros(c2, np.float32),
                rng.normal(0, np.sqrt(1 / (25 * c2)), (25 * c2, 10)).astype(np.float32), np.zeros(10, np.float32)]

    def _fw(self, w, X):
        n = X.shape[0]
        c1 = im2col(X, 5)                                     # n,28,28,75
        z1 = c1 @ w[0] + w[1]                                 # n,28,28,8
        a1 = np.maximum(z1, 0).transpose(0, 3, 1, 2)          # n,8,28,28
        p1, m1 = pool_fw(a1)                                  # n,8,14,14
        p1c = np.ascontiguousarray(p1)
        c2 = im2col(p1c, 5)                                   # n,10,10,200
        z2 = c2 @ w[2] + w[3]                                 # n,10,10,16
        a2 = np.maximum(z2, 0).transpose(0, 3, 1, 2)          # n,16,10,10
        p2, m2 = pool_fw(a2)                                  # n,16,5,5
        f = p2.reshape(n, -1)
        z = f @ w[4] + w[5]
        z = z - z.max(1, keepdims=True)
        p = np.exp(z)
        p /= p.sum(1, keepdims=True)
        return (c1, z1, m1, p1c, c2, z2, m2, f), p

    def forward(self, w, X):
        out = []
        for s in range(0, len(X), 500):
            out.append(self._fw(w, X[s:s + 500])[1])
        return np.vstack(out)

    def grad(self, w, X, y):
        (c1, z1, m1, p1c, c2, z2, m2, f), p = self._fw(w, X)
        n = len(y)
        p[np.arange(n), y] -= 1
        p /= n
        g4 = f.T @ p
        g5 = p.sum(0)
        df = (p @ w[4].T).reshape(n, self.c2, 5, 5)
        da2 = pool_bw(df, m2)                                 # n,16,10,10
        dz2 = da2.transpose(0, 2, 3, 1) * (z2 > 0)            # n,10,10,16
        g2 = c2.reshape(-1, c2.shape[-1]).T @ dz2.reshape(-1, self.c2)
        g3 = dz2.sum((0, 1, 2))
        dc2 = dz2 @ w[2].T                                    # n,10,10,200
        dp1 = col2im(dc2, p1c.shape, 5)                       # n,8,14,14
        da1 = pool_bw(dp1, m1)                                # n,8,28,28
        dz1 = da1.transpose(0, 2, 3, 1) * (z1 > 0)
        g0 = c1.reshape(-1, 75).T @ dz1.reshape(-1, self.c1)
        g1 = dz1.sum((0, 1, 2))
        return [g0, g1, g2, g3, g4, g5]


def load_cifar(root="/home/claude/data/cifar-10-batches-py"):
    def ld(f):
        d = pickle.load(open(os.path.join(root, f), "rb"), encoding="bytes")
        return d[b"data"].reshape(-1, 3, 32, 32).astype(np.float32) / 255.0, np.array(d[b"labels"])
    Xs, ys = zip(*[ld(f"data_batch_{i}") for i in range(1, 6)])
    Xtr, ytr = np.concatenate(Xs), np.concatenate(ys)
    Xte, yte = ld("test_batch")
    mean = Xtr.mean((0, 2, 3), keepdims=True); std = Xtr.std((0, 2, 3), keepdims=True)
    return (Xtr - mean) / std, ytr, (Xte - mean) / std, yte
