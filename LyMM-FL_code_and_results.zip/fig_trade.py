import pickle, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
exec(open("figs_main.py").read().split("R = {m:")[0])
S=pickle.load(open("results/trade_summary.pkl","rb"))
rs=[0.0,0.05,0.1,0.15,0.2]
def ms(f,key): v=[[f(r) for r in S[key]] for key in key]; return np.mean(v,1), np.std(v,1,ddof=1)
keys=[("r",r) for r in rs]
panels=[(lambda r:r["last_acc"].mean()*100,"Mean accuracy (%)"),(lambda r:r["jain"],"Jain's index"),
        (lambda r:r["E_mean"]*1e3,"Energy (mJ / device / round)"),(lambda r:r["frac_over"]*100,"Devices over allowance (%)")]
fig,axs=plt.subplots(1,4,figsize=(10.5,2.6))
for ax,(f,lab) in zip(axs,panels):
    mu,sd=ms(f,keys)
    ax.errorbar(rs,mu,yerr=sd,color=COL["LyMM-FL"],lw=2,marker="o",ms=4,capsize=2,ecolor=MUTED)
    ax.set_xlabel("Fairness target r_min"); ax.set_title(lab,fontsize=9,color=INK); ax.set_xticks(rs)
fig.tight_layout(); fig.savefig("fig6_fairness_tradeoff.png"); print("ok")
